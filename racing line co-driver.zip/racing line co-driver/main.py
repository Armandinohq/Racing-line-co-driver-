import pygame
from math import sin,cos,atan,atan2
import random
import time
import tkinter as tk
from tkinter import filedialog
import os
#import matplotlib.pyplot as plt

pygame.init()
win = pygame.display.set_mode((800,600))
#bg=pygame.image.load("hungry.png").convert()
#bg=pygame.transform.smoothscale(bg,(800,600))
speedometer=pygame.image.load("speedometer.png").convert()
speedometer=pygame.transform.smoothscale(speedometer,(200,50))
Button=pygame.image.load("black button.png")
Button=pygame.transform.smoothscale(Button,(100,50))
#win.blit(bg,(0,0))
pygame.display.update()
pygame.display.set_caption("racing line")
#mainCarImage=pygame.image.load("cary.png")
#mainCarImage=pygame.transform.scale(mainCarImage, (50,72))
#mainCarImage=pygame.transform.rotate(mainCarImage, 50)
run = True
turn=1
oneTime=True
laps=0
checkpointReached=False
ba="baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
mode="menu"
inProgram=True
onExportBotton=True
setupStage = "start"
start_pos = None
end_pos = None
checkpoint_pos = None
start_direction = None
track_turn = None
text_input = ""
class Car:
    def __init__(self,speed,direction,x,y):
        self.speed=speed
        self.direction=direction
        self.x=x
        self.y=y
        self.startX= self.x
        self.startY=self.y
        self.startDirection=self.direction
        self.position=[]
        self.oneLapComplited=False
        self.analisedTrack=[]
        self.prevDirection=self.direction
        self.bestLapTime=float("inf")
        self.bestLapPositions=[]
        self.lapStartTime=0
        self.turnAhead=0
        self.lapSpeedPositions=[]
        self.bestLapSpeedPositions=[]
        self.lapMidispeed=0
        self.bestlapMidispeed=-1
    def fd(self):
        global laps
        global run
        global checkpointReached
        Vx = self.speed * cos(directionToRadian(self.direction))
        Vy = self.speed * sin(directionToRadian(self.direction))
        self.x = self.x + Vx
        self.y = self.y + Vy
        self.position.append((self.x, self.y))
        self.lapSpeedPositions.append(self.speed)

        delta = abs(self.direction - self.prevDirection)
        if delta > 5:
            if self.speed > 1.0:
                self.speed -= 0.2
        elif self.speed < 4:
            self.speed += 0.15

        self.prevDirection = self.direction

        if abs(self.x - self.position[0][0]) < 20 and abs(self.y - self.position[0][1]) < 20:
            if checkpointReached:
                self.oneLapComplited = True
                checkpointReached = False
                lapEndTime = time.time()
                lapTime = lapEndTime - self.lapStartTime

                self.lapMidispeed = sum(self.lapSpeedPositions) / len(self.lapSpeedPositions)
                print(f"Lap score: {self.lapMidispeed:.3f} points")
                print(f"Lap Time: {lapTime:.3f} seconds")

                if lapTime < self.bestLapTime:
                    self.bestLapTime = lapTime
                    self.bestlapMidispeed = self.lapMidispeed
                    self.bestLapPositions = self.position.copy()
                    self.bestlapSpeedPositions = self.lapSpeedPositions.copy()
                    self.smoothPath()
                    print("nEw ReCoRd")

                self.x = self.startX
                self.y = self.startY
                self.direction = self.startDirection
                self.position = []
                self.lapSpeedPositions = []
                self.lapStartTime = time.time()
                laps += 1
                print(f"Lap {laps} completed")
                win.blit(bg, (0, 0))
                pygame.display.update()               
    def lookAheadAndReact(self, track):
        self.reactToNearestBestPoint()
        for z in range(-2, 3):
            for n in [10, 20, 30]:
                Xs = n * cos(directionToRadian(self.direction + z))
                Ys = n * sin(directionToRadian(self.direction + z))
                color = win.get_at((round(self.x + Xs), round(self.y + Ys)))
                brakePower = 0.3
                horsePower = 0.15
                if color == (27, 0, 135, 255):
                    if turn == 1:
                        self.direction += 2
                        if self.speed >= 1.0:
                            self.speed -= brakePower
                    if turn == -1:
                        self.direction -= 2
                        if self.speed >= 1.0:
                            self.speed -= brakePower
                elif color == (58, 172, 19, 255):
                    if turn == 1:
                        self.direction -= 2
                        if self.speed >= 1.0:
                            self.speed -= brakePower
                    if turn == -1:
                        self.direction += 2
                        if self.speed >= 1.0:
                            self.speed -= brakePower
                elif self.speed <= 4:
                    self.speed += horsePower
    def analisingTrack(self):
        dp = 5
        if self.oneLapComplited:
            for i in range (len(self.position)-(dp+1)):
                if (self.position[i+dp][0]-self.position[i][0])==0:
                    if (self.position[i+dp+1][0]-self.position[i+1][0])==0:
                        flag=True
                elif (self.position[i+dp+1][0]-self.position[i+1][0])==0:
                    flag = False
                else:    
                    lineAngle=(self.position[i+dp][1]-self.position[i][1])/(self.position[i+dp][0]-self.position[i][0])-(self.position[i+dp+1][1]-self.position[i+1][1])/(self.position[i+dp+1][0]-self.position[i+1][0])
                    angle = atan(lineAngle)
                    if abs(angle)<4.5 * (3.14/180):
                        flag=True
                    else:
                        flag=False
                self.analisedTrack.append(flag)
    def checkpointReachedFun(self):
        global checkpointReached
        global checkpointX
        global checkpointY
        if abs(self.x - track.checkpointX) < 20 and abs(self.y - track.checkpointY) < 20:
            checkpointReached = True
    def randomChanges(self):
        if laps < 100:
            max_random = max(0, 15 * (0.9 ** laps))
            x = random.randint(-int(max_random), int(max_random))
            self.direction += x
    def turnPrepretion(self):
        for z in range(-2,3):
            #flag1=True
            
            Xs = 40 * ((cos(directionToRadian(self.direction+z))))
            Ys = 40 * ((sin(directionToRadian(self.direction+z))))
            color=win.get_at(((round(self.x + Xs),(round(self.y + Ys)))))
            if color==(29,0,137,255):
                if turn==1:
                    self.turnAhead-=1
                if turn==-1:
                    self.turnAhead+=1    

            if color==(60,174,21,255):
                if turn==1:
                    self.turnAhead+=1
                if turn==-1:
                    self.turnAhead-=1
        if self.turnAhead>=2:
            self.direction+=random.randint(0, 1)
        elif self.turnAhead<=-2:
            self.direction-=random.randint(0, 1)
        #show sensor
        #pygame.draw.circle(win, (0,0,0), (self.x + Xs,self.y + Ys), 2)
        #pygame.display.update()  
    def getNearestBestPoint(self):
        if not self.bestLapPositions:
            return None

        minDist = float('inf')
        nearestPoint = None

        for point in self.bestLapPositions:
            dx = point[0] - self.x
            dy = point[1] - self.y
            #print("dx:", dx,"dy:", dy,"cos:",cos(directionToRadian(self.direction)),"sin:",sin(directionToRadian(self.direction)))
            dotProduct = dx * cos(directionToRadian(self.direction)) + dy * sin(directionToRadian(self.direction))

            if dotProduct > 0:  # فقط نقاطی که جلوتر از ماشین هستن رو بررسی کن
                dist = (dx**2 + dy**2) ** 0.5
                if dist < minDist:
                    minDist = dist
                    nearestPoint = point
                    nearestPoint 
        return nearestPoint
    def getNearestBestPointspped(self):
            if not self.bestLapPositions:
                return None

            minDist = float('inf')
            nearestPoint = None

            for point in range (len(self.bestLapPositions)):
                dx = self.bestLapPositions[point][0] - self.x
                dy = self.bestLapPositions[point][1] - self.y
                #print("dx:", dx,"dy:", dy,"cos:",cos(directionToRadian(self.direction)),"sin:",sin(directionToRadian(self.direction)))
                dotProduct = dx * cos(directionToRadian(self.direction)) + dy * sin(directionToRadian(self.direction))

                if dotProduct > 0:  # فقط نقاطی که جلوتر از ماشین هستن رو بررسی کن
                    dist = (dx**2 + dy**2) ** 0.5
                    if dist < minDist:
                        minDist = dist
                        nearestPointspeed= point
            return nearestPoint
    def reactToNearestBestPoint(self):
        nearestPoint = self.getNearestBestPoint()
        if nearestPoint is not None:
            self.direction = self.direction % 360
            targetAngle = radianToDirection(atan2(nearestPoint[1] - self.y, nearestPoint[0] - self.x))
            angleDiff = (targetAngle - self.direction + 180) % 360 - 180
            self.direction += angleDiff * 0.05
    def reactToNearestBestPointSpeed(self):
         nearestPointSpeed = self.getNearestBestPointspped()
         if nearestPointSpeed<self.bestlapMidispeed-2.5:
            self.direction+=random.randint(-4, 4)
    def smoothPath(self):
        if len(self.bestLapPositions) < 3:  # اگه نقاط کافی نباشه، کاری نمی‌کنیم
            return
        smoothedPath = [self.bestLapPositions[0]]  # نقطه شروع
        for i in range(1, len(self.bestLapPositions) - 1):
            p1 = self.bestLapPositions[i - 1]
            p2 = self.bestLapPositions[i]
            p3 = self.bestLapPositions[i + 1]
            # محاسبه زاویه بین نقاط
            angle1 = atan2(p2[1] - p1[1], p2[0] - p1[0])
            angle2 = atan2(p3[1] - p2[1], p3[0] - p2[0])
            if abs(angle1 - angle2) < 0.087:  # حدود ۵ درجه
                smoothedPath.append(p2)  # اگه زاویه کمه، نقطه رو نگه می‌داریم
            else:
                smoothedPath.append(p2)  # اگه نه، بازم نقطه رو نگه می‌داریم (برای پیچ‌ها)
        smoothedPath.append(self.bestLapPositions[-1])  # نقطه آخر
        self.bestLapPositions = smoothedPath  # مسیر جدید رو ذخیره می‌کنیم
class track:
    def __init__(self,checkpointX,checkpointY):
        self.checkpointX=checkpointX
        self.checkpointY=checkpointY           
def limitNumber(a, b, m):
    n = a * b
    if n > m:
        return m
    return n      
def directionToRadian(degree):
        return (degree-90)*3.14/180
def radianToDirection(radian):
        return radian*180/3.14 + 90
def redrawGameWindowInWorkMode():
    global car
    global bg
    pygame.draw.circle(win, (120,0,120), (car.x,car.y), 2)
    pygame.draw.circle(win, (255,255,0), (track.checkpointX,track.checkpointY), 1)
    win.blit(speedometer,(800-210,600-60))
    pygame.draw.rect(win,(255,0,255),(800-210,600-60,car.speed*50,50))
    pygame.draw.line(win, (0,0,0), (car.speed*50+800-210,600-60),(car.speed*50+800-210,600-10),3)
    pygame.draw.rect(win,(255,0,0),(20,20,75,30))
    text_font=pygame.font.Font("HARLOWSI.TTF",30)
    def draw_text(text,font,text_col,x,y):
        img=font.render(text,True,text_col)
        win.blit(img,(x,y))
    draw_text(str("export"),text_font,(0,0,0),21,14)
    pygame.display.update()
def redrawGameWindowInExporting():

    win.blit(bg, (0, 0))  

    for pos in car.bestLapPositions:
        pygame.draw.circle(win, (255, 0, 0), ((pos[0]),(pos[1])), 2)  

    text_font=pygame.font.Font("HARLOWSI.TTF",30)
    def draw_text(text,font,text_col,x,y):
        img=font.render(text,True,text_col)
        win.blit(img,(x,y))
    draw_text(str(f"Fastest Lap Time: {car.bestLapTime:.3f} seconds"),text_font,(0,0,0),50,550) 
    draw_text(str("best racing line found"),text_font,(0,0,0),50,30)
    pygame.display.update()
def redrawGameWindowInMenu():
    global Button
    Button=pygame.transform.smoothscale(Button,(200,120))
    menuBg=pygame.image.load("logo.png")
    menuBg=bg=pygame.transform.smoothscale(menuBg,(800,600))
    win.blit(menuBg,(0,0))
    text_font=pygame.font.Font("HARLOWSI.TTF",90)
    def draw_text(text,font,text_col,x,y):
        img=font.render(text,True,text_col)
        win.blit(img,(x,y))
    draw_text(str("start"),text_font,(0,127,192),315,450)
    pygame.display.update()
def redrawGameWindowInSetup():
    win.blit(bg, (0, 0))

    font=pygame.font.Font("HARLOWSI.TTF",32)
    # نمایش نقاط انتخاب‌شده
    if start_pos:
        pygame.draw.circle(win, (0, 255, 0), start_pos, 6)  # شروع - سبز
        None
    if end_pos:
        pygame.draw.circle(win, (255, 0, 0), end_pos, 6)    # پایان - قرمز
    if checkpoint_pos:
        pygame.draw.circle(win, (255, 255, 0), checkpoint_pos, 6)  # چک‌پوینت - زرد

    # نمایش پیام‌ها و ورودی عددی
    if setupStage == "start":
        prompt = font.render("enter start-end point:", True, (0, 0, 0))
        win.blit(prompt, (20, 20))
    if setupStage == "checkpoint":
        prompt = font.render("enter a chepoint in the track far from the start-end point:", True, (0, 0, 0))
        win.blit(prompt, (20, 20))
    elif setupStage == "angle":
        prompt = font.render("enter starting angle(0:up):", True, (0, 0, 0))
        win.blit(prompt, (20, 20))
    elif setupStage == "turn":
        prompt = font.render("enter track direction 1=cw,-1=ccw", True, (0, 0, 0))
        win.blit(prompt, (20, 20))

    if setupStage in ["angle", "turn"]:
        user_input_text = font.render(text_input, True, (0,127,192))
        win.blit(user_input_text, (20, 60))

    pygame.display.update()
def selectImage():
    root=tk.Tk()
    root.withdraw()
    filePath=filedialog.askopenfilename(title="select track image",filetypes=[("image files","*png;*.jpg;*.jpeg")])
    root.destroy()
    return filePath
carFlag=True
while run:
    if mode =="work":
        if carFlag:
            car=Car(1,start_direction,start_pos[0],start_pos[1])
            #car=car(1,0,182,420)
            carFlag=False
            print(ba)
            win.blit(bg,(0,0))
        car.checkpointReachedFun()
        #car.turnPrepretion()
        car.fd()
        car.lookAheadAndReact(track)
        car.randomChanges()
        if oneTime and car.oneLapComplited:
            car.analisingTrack()
            oneTime=False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
            if event.type == pygame.KEYDOWN: 
                if event.key == pygame.K_SPACE:
                    print(laps)
            if event.type== pygame.MOUSEBUTTONDOWN:
                pos=event.pos
                print(pos)
                if 20<pos[0]<20+75 and 20<pos[1]<20+30:
                    mode="exporting"
        redrawGameWindowInWorkMode()
        pygame.time.Clock().tick(600)
    elif mode=="exporting":
        redrawGameWindowInExporting()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
    elif mode=="menu":
        redrawGameWindowInMenu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
            if event.type== pygame.MOUSEBUTTONDOWN:
                pos=event.pos
                print(pos)
                if 300<pos[0]<450+200 and 300<pos[1]<450+100:
                    imagePath=selectImage()
                    if imagePath:
                        bg=pygame.image.load(imagePath).convert()
                        bg=pygame.transform.smoothscale(bg, (800,600))
                        win.blit(bg, (0,0))
                        pygame.display.update()
                        mode="setup"
    if mode == "setup":
        flagSetup=False
        redrawGameWindowInSetup()
        for event in pygame.event.get():   
            if event.type == pygame.QUIT:
                run=False
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if setupStage == "start":
                    start_pos = pos
                    print("Start point set at", pos)
                    setupStage = "checkpoint"
                elif setupStage == "checkpoint":
                    checkpoint_pos = pos
                    track=track(pos[0],pos[1])
                    print("Checkpoint set at", pos)
                    setupStage = "angle"
                    text_input = ""
                    print("Enter start angle (e.g. 90):")
            if event.type == pygame.KEYDOWN:
                if setupStage in ["angle", "turn"]:
                    if event.key == pygame.K_RETURN:
                        try:
                            value = int(text_input)
                            if setupStage == "angle":
                                start_direction = value
                                setupStage = "turn"
                                text_input = ""
                            elif setupStage == "turn":
                                if value in [1, -1]:
                                    turn = value
                                    mode = "work"
                                    setupStage = None
                                else:
                                    text_input = ""
                        except:
                            text_input = ""
                        flagSetup=True
                    elif event.key == pygame.K_BACKSPACE:
                        text_input = text_input[:-1]
                    else:
                        if len(text_input) < 5:
                            text_input += event.unicode


        
pygame.quit()
